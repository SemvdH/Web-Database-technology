module.exports = {
    timesVisited: 0
};