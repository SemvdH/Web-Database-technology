----- battleship implementation made by Dan Dan Berendsen & Sem van der Hoeven ------

-our 'myapp' folder is called 'battleship'

-this file zip folder (Assignment2-files-CSE2_50) contains all files for running the game

-we made use of the cookie-parser, so please install it using: npm install cookie-parser -g
